const express = require('express');
const router = express.Router();
const sess = require('../sessionHelper');

router.get('/comments', (req, res) => {
  sess.initSession(req);
  let user = sess.getUser(req) || 'guest';
  if (user === 'guest') return res.redirect('/');
  let msgHtml = sess.getMessages(req).map(m => `<li>${m}</li>`).join('');
  let html = require('fs').readFileSync(__dirname + '/../views/comments.html', 'utf-8');
  html = html.replace('{{user}}', user).replace('{{messages}}', msgHtml);
  res.send(html);
});

router.post('/comments', (req, res) => {
  sess.initSession(req);
  let user = sess.getUser(req) || 'guest';
  if (user === 'guest') return res.redirect('/');
  let msg = req.body.msg || '';
  sess.addMessage(req, msg);
  res.redirect('/comments');
});

module.exports = router;
