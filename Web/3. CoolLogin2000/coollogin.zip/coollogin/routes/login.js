const express = require('express');
const router = express.Router();
const sess = require('../sessionHelper');

router.post('/login', (req, res) => {
  sess.initSession(req);
  let user = req.body.user || 'guest';
  sess.loginUser(req, user);
  res.redirect('/comments');
});

module.exports = router;
