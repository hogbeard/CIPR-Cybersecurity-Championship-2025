// app.js
const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');
const sess = require('./sessionHelper');

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));

app.use(session({
  secret: 'solar-session',
  resave: false,
  saveUninitialized: true,
  cookie: { httpOnly: false, secure: false }
}));

app.use(require('./routes/login'));
app.use(require('./routes/comments'));

app.get('/', (req, res) => {
  let html = `
  <!DOCTYPE html>
  <html>
  <head>
    <meta charset="utf-8">
    <title>COOL_LOGIN_2000</title>
    <style>
      html, body { height: 100%; margin: 0; padding: 0; }
      body {
        background: #181818;
        color: #ee6132;
        font-family: 'Segoe UI', monospace, sans-serif;
        height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
      }
      .box {
        min-width: 300px;
        width: 370px;
        border: 2px solid #ee6132;
        padding: 2.5em 2em 2em 2em;
        border-radius: 2em;
        background: #222;
        box-shadow: 0 8px 40px #ee6132a0;
        display: flex;
        flex-direction: column;
        align-items: center;
      }
      h2 {
        margin-bottom: 2em;
        letter-spacing: 1px;
        text-align: center;
      }
      form {
        width: 100%;
        margin-bottom: 1.7em;
        display: flex;
        flex-direction: column;
        gap: 1em;
        align-items: center;
      }
      input[type="text"] {
        width: 90%;
        padding: 0.7em;
        border-radius: 8px;
        border: 1.5px solid #ee6132;
        background: #1a1a1a;
        color: #ee6132;
        font-size: 1em;
      }
      button {
        width: 70%;
        padding: 0.7em 0;
        background: #ee6132;
        color: #fff;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-weight: bold;
        font-size: 1em;
        transition: background 0.2s;
      }
      button:hover {
        background: #ff954a;
      }
    </style>
  </head>
  <body>
    <div class="box">
      <h2>Welcome to<br>COOL_LOGIN_2000</h2>
      <form method="POST" action="/login" autocomplete="off">
        <input name="user" placeholder="Login as..." maxlength="30" required>
        <button type="submit">Login</button>
      </form>
    </div>
  </body>
  </html>
  `;
  res.send(html);
});

app.listen(3000, () => {
  console.log('COOL_LOGIN_2000 running on :3000');
});
