from flask import Flask, request, render_template, redirect, make_response
import sqlite3
import base64
import os
import hashlib
import hmac
import re
import random
import string

app = Flask(__name__)
def create_session(data: dict, username: str) -> str:
    key = b"user_" + username.encode()
    raw = str(data).encode()
    sig = hmac.new(key, raw, hashlib.sha256).hexdigest()
    session = base64.urlsafe_b64encode(raw + b"." + sig.encode()).decode()
    return session
def deserialize_session(session_str: str, username: str) -> dict:
    try:
        raw = base64.urlsafe_b64decode(session_str.encode())
        data, sig = raw.rsplit(b".", 1)
        key = b"user_" + username.encode()
        expected_sig = hmac.new(key, data, hashlib.sha256).hexdigest().encode()
        if not hmac.compare_digest(sig, expected_sig):
            return {}
        return eval(data.decode())  # ⚠️ опасная зона
    except:
        return {}
def init_db():
    if not os.path.exists("users.db"):
        conn = sqlite3.connect("users.db")
        c = conn.cursor()
        c.execute("CREATE TABLE users (username TEXT PRIMARY KEY, password TEXT)")
        c.execute("INSERT INTO users VALUES (?, ?)", ("admin", "SuperSecretPassword"))
        conn.commit()
        conn.close()

    if not os.path.exists("logs"):
        os.makedirs("logs")
@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        uname = request.form.get("username")
        passwd = request.form.get("password")
        conn = sqlite3.connect("users.db")
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username=? AND password=?", (uname, passwd))
        row = c.fetchone()
        conn.close()
        if row:
            resp = make_response(redirect("/admin"))
            session_obj = {"username": uname, "role": "user"}
            if uname == "admin":
                session_obj["role"] = "admin"
            cookie_val = create_session(session_obj, uname)
            resp.set_cookie("session", cookie_val)
            return resp
    return render_template('login.html')

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username")
        if username.lower() == "superadmin":
            return "This user is reserved."
        password = request.form.get("password")
        conn = sqlite3.connect("users.db")
        c = conn.cursor()
        try:
            c.execute("INSERT INTO users VALUES (?, ?)", (username, password))
            conn.commit()
        except sqlite3.IntegrityError:
            return "User already exists"
        finally:
            conn.close()
        resp = make_response(redirect("/"))
        session_data = {"username": username, "role": "user"}
        cookie = create_session(session_data, username)
        resp.set_cookie("session", cookie)
        return resp
    return render_template("register.html")

@app.route("/admin")
def admin_panel():
    sess = request.cookies.get("session")
    if not sess:
        return "Access Denied", 403
    try:
        raw = base64.urlsafe_b64decode(sess.encode())
        data, sig = raw.rsplit(b".", 1)
        username = eval(data.decode()).get("username")
        session_data = deserialize_session(sess, username)
    except:
        return "Access Denied", 403
    if session_data.get("role") == "admin":
        return render_template("admin.html")
    if session_data.get("role") == "superadmin":
        return render_template("superadmin.html")
    if (session_data.get("role") != "admin" or session_data.get("role") != "superadmin"):
        return render_template("access.html")
    return "Access Denied", 403
@app.route("/s3cr3t", methods=["GET", "POST"])
def secret_panel():
    sess = request.cookies.get("session")
    if not sess:
        return "Admins only", 403
    try:
        raw = base64.urlsafe_b64decode(sess.encode())
        data, sig = raw.rsplit(b".", 1)
        username = eval(data.decode()).get("username")
        session_data = deserialize_session(sess, username)
    except:
        return "Admins only", 403

    if session_data.get("role") != "superadmin":
        return "Superadmins only", 403

    if request.method == "POST":
        log = request.form.get("log")
        if re.search(r"\.\.", log):
            return "Blocked"
        try:
            full_path = os.path.normpath(os.path.join("logs", log))
            with open(full_path, "r") as f:
                content = f.read()
            return render_template("log_viewer.html", content=content)
        except FileNotFoundError:
            return render_template("log_viewer.html", error="File not found")
        except Exception as e:
            return render_template("log_viewer.html", error=str(e))
    return render_template("secret.html")
if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000)
