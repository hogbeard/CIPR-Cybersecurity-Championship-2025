"""YALF"""
import argparse
import base64
import hashlib
import logging
import os
import sqlite3
import sys
import time

from logging import info, warning, error
from flask import Flask, request, render_template

ISO_DATE_FORMAT = '%Y-%m-%d %H:%M:%S'
LOG_MSG_FORMAT = '%(asctime)s %(levelname)s: %(message)s'

app = Flask(__name__)
title = sys.modules[__name__].__doc__.strip().rstrip('.')

conn = sqlite3.connect(':memory:', check_same_thread=False)
cursor = conn.cursor()

def restore_db():
    """Restore in-memory SQLite database."""
    global conn, cursor
    conn.close()

    conn = sqlite3.connect(':memory:', check_same_thread=False)
    cursor = conn.cursor()

    cursor.execute('CREATE TABLE IF NOT EXISTS users (username TEXT, '
                   'password TEXT)')

    sha256_hash = hashlib.sha256()
    sha256_hash.update(b'I.MF,A.|!)6ij}A`>>xf')

    cursor.execute("INSERT INTO users VALUES (?, ?)",
                   ['solar', sha256_hash.hexdigest()])

    conn.commit()

restore_db()

@app.route('/', methods=['GET', 'POST'])
def index():
    message = 'please enter valid login and password'
    is_logged = False

    try:
        if request.method == 'POST':
            time.sleep(0.2) 

            try:
                username = request.form['uC2Dvd']
                password = request.form['gAUqev']

                username = base64.b64decode(username.encode()).decode()

            except Exception:
                username = '<not decoded>'

            info('trying user "%s" by %s: %s',
                 username, request.remote_addr, dict(request.form))
           
            sql_request = ('SELECT * FROM users WHERE '
                           f"username = '{username}' AND password = ?")

            info('sql request "%s"', sql_request)

            cursor.execute(sql_request, [password])

            is_logged = cursor.fetchone()

            if is_logged:
                message = 'successfully logged in!'

            else:
                message = 'invalid login or password!'

            restore_db()

    except Exception as exc:
        error(exc)
        message = str(exc).lower()

    return render_template(
        'index.html',
        title=title,
        message=message
    )

def init_log():
    """Init logging to display/file."""

    if os.path.isdir('/log/'):
        log_file = '/log/app.log'

    else:
        log_file = None

    for level in [(logging.INFO,    'info'),
                  (logging.WARNING, 'warning'),
                  (logging.ERROR,   'error')]:
        logging.addLevelName(*level)

    logging.basicConfig(level=logging.INFO,
                        datefmt=ISO_DATE_FORMAT,
                        format=LOG_MSG_FORMAT)

    if log_file is not None:
        filelog = logging.FileHandler(filename=log_file, mode='a',
                                      encoding='utf-8')

        filelog.setFormatter(logging.Formatter(datefmt=ISO_DATE_FORMAT,
                                               fmt=LOG_MSG_FORMAT))

        logging.getLogger().addHandler(filelog)

        info(f'logging to file: {log_file}')

    else:
        info('no file logging available')

def main():
    parser = argparse.ArgumentParser(
        description=sys.modules[__name__].__doc__.strip()
    )

    parser.add_argument('-p', '--port', type=int, default=5000,
                        help='http port for flask service')

    parser.add_argument('-d', '--debug', action='store_true',
                        help='start flask in debug mode')

    params = parser.parse_args()

    init_log()
    app.run(host='0.0.0.0', port=params.port, debug=params.debug)

if __name__ == '__main__':
    try:
        main()

    except KeyboardInterrupt:
        pass